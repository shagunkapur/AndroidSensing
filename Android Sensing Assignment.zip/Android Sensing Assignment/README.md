# Acceleration and Gyroscope
Features: 
1. Clicking on the Record button helps in visualising and saving accelerometer and gyroscope raw data.
2. Stop button stops listening to the sensors and stops appending to the file.
3. Reset button resets the textview and deletes the txt file.
